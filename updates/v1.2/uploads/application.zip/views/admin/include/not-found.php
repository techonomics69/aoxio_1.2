<div class="empty-data text-center">
  <img src="<?php echo base_url('assets/images/empty-folder.png') ?>">
  <p><?php echo trans('no-data-found') ?></p>
</div>